from flask import Flask, render_template, request
from flask_pymongo import PyMongo


app = Flask(__name__)
app.config["MONGO_URI"] = "mongodb://localhost:27017/survey"
mongo = PyMongo(app)


@app.route("/")
def index():

    return render_template("index.html")


@app.route("/submit", methods=["POST"])
def submit():
   
    name = request.form["name"]
    age = request.form["age"]
    gender = request.form["gender"]
    income = request.form["income"]
    expenses = {}
    categories = [
        "utilities",
        "entertainment",
        "school_fees",
        "shopping",
        "healthcare",
    ]
    for category in categories:
        expenses[category] = float(request.form.get(category, 0))

 
    client = mongo.db
    collection = client["users"]

    collection.insert_one(
        {
            "name": name,
            "age": age,
            "gender": gender,
            "income": income,
            "expenses": expenses,
        }
    )

    return render_template("success.html")
