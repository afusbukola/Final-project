import csv
import pandas as pd
from user import User
import pymongo

client = pymongo.MongoClient("mongodb://localhost:27017/")

# connect to survey database
db = client["survey"]

# access users collection
collection = db.users


# Create user objects and store in list
users = []
for item in list(collection.find()):
    user = User(
        item["name"], item["age"], item["gender"], item["income"], item["expenses"]
    )
    user_data = {
        "name": user.name,
        "age": user.age,
        "gender": user.gender,
        "income": user.income,
        "expenses": user.expenses,
    }
    users.append(user_data)



# Open and write to CSV
with open("user_data.csv", "w", newline="") as csv_file:
    fieldnames = ["name", "age", "gender", "income"] + list(users[0]["expenses"].keys())
    writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
    writer.writeheader()
    for user in users:
        data = {
            "name": user["name"],
            "age": user["age"],
            "gender": user["gender"],
            "income": user["income"],
        }
        data.update(user["expenses"])
        writer.writerow(data)
