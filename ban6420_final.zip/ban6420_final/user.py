class User:
    def __init__(self, name, age, gender, income, expenses):
        self.name = name
        self.age = age
        self.gender = gender
        self.income = income
        self.expenses = expenses